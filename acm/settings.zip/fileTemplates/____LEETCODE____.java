#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import java.io.*;
import java.util.*;
import static java.lang.System.out;

public class ${CLASS_NAME} {
    
    public static void main(String[] args) throws IOException {
        List<Boolean> l = new ArrayList<>();
        ${CLASS_NAME} s = new ${CLASS_NAME}();

        l.add(s.solution() == 0);
        //l.add(Arrays.equals(s.solution(), new int[]{));
        
        if (!l.contains(false)) out.println("All Test Cases Passed.");
        else for (int i = 0; i < l.size(); i++)if (!l.get(i)) out.println("Case " + (i + 1) + ": Failed");
    }
    
    public int solution() {
        
        
        
        return 0;
    }
}